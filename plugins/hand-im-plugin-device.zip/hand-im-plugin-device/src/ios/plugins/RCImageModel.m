//
//  RCImageModel.m
//  HelloCordova
//
//  Created by wangsheng on 16/8/10.
//
//

#import "RCImageModel.h"

@implementation RCImageModel

@end
