//
//  CVDPlugin-Bridging-Header.h
//  IMTest
//
//  Created by wangsheng on 16/7/11.
//
//

#import <RongIMKit/RongIMKit.h>

#ifndef CVDPlugin_Bridging_Header_h

#define appKey @"0vnjpoadnd4cz"
#define appSecret @"5g2v4RnSnGU"
#define CDVIMPluginPushNotification @"CDVIMPluginPushNotification"

#endif /* CVDPlugin_Bridging_Header_h */

